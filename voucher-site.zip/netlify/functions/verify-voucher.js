import fetch from "node-fetch";

export async function handler(event) {
  const { code } = JSON.parse(event.body || "{}");
  if (!code) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing code" }) };
  }

  const githubToken = process.env.GITHUB_TOKEN;
  const owner = "paknet";
  const repo = "vouchers.db";

  try {
    const res = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/vouchers.json`,
      {
        headers: { Authorization: `token ${githubToken}` }
      }
    );

    const data = await res.json();
    const fileContent = Buffer.from(data.content, "base64").toString("utf8");
    const vouchers = JSON.parse(fileContent);

    const profile = vouchers[code];
    const valid = !!profile;

    return {
      statusCode: 200,
      body: JSON.stringify({ valid, profile: valid ? profile : null })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}
